﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Replayer.Live.Portable
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// <remarks>This is a wrapper program, used for having a separate
        /// visual studio project for the portable version of the Replayer Live
        /// application.</remarks>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new RePlayer.Face.Live.ReplayerLiveApplicationForm());
        }
    }
}
