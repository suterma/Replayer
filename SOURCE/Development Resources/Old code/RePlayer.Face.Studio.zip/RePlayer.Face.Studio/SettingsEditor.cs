﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;

namespace AdoniaReplayerProto
{
    public partial class SettingsEditor : Form
    {
        public SettingsEditor(ApplicationSettingsBase settings)
        {
            InitializeComponent();
            propertyGrid1.SelectedObject = settings;        
        }

        private void _btnSave_Click(object sender, EventArgs e)
        {
            ((ApplicationSettingsBase)propertyGrid1.SelectedObject).Save();
            this.Close();
        }

        private void propertyGrid1_Click(object sender, EventArgs e)
        {

        }
    }
}
