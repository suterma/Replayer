﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using RePlayer.Core.Annotation.v03;

namespace AdoniaReplayerProto
{
    public partial class CompilationEditor : Form
    {
        internal CompilationEditor(ICompilation Compilation)
        {
            InitializeComponent();

            _pgTracks.SelectedObject = Compilation;
        }
    }
}
