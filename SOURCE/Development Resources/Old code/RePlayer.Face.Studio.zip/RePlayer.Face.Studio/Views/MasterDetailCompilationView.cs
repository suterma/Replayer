﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using RePlayer.Core.Annotation.v03;

namespace AdoniaReplayerProto.Views
{
    public partial class MasterDetailCompilationView : UserControl
    {
        /// <summary>
        /// Backing field for the Compilation property
        /// </summary>
        private ICompilation _Compilation;

        /// <summary>
        /// Gets or sets the Compilation.
        /// </summary>
        /// <value>The Compilation.</value>
        public ICompilation Compilation
        {
            private get
            {
                return _Compilation;
            }
            set
            {
                _Compilation = value; //store in backing field for later use

                //put the tracks into the left datagridview, with an index
                _dgvTracks.DataSource = (Compilation.Tracks.Select((item, index) =>
                                new
                                {
                                    Title = item.TrackInfo.Name
                                })).ToList(); //usage of toList is necessary for databinding with a datagridview
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MasterDetailCompilationView"/> class.
        /// </summary>
        public MasterDetailCompilationView()
        {
            InitializeComponent();

        }

        /// <summary>
        /// Selects the cue point.
        /// </summary>
        /// <param name="cuePoint">The cue point.</param>
        public void SelectCuePoint(CuePoint cuePoint)
        {
            if (cuePoint != null) //there is any specific requested?
            {
                //select the track of the cuepoint in the master view
                var track = Compilation.Tracks.Select((item, index) =>
                                     new
                                     {
                                         Title = item.TrackInfo.Name,
                                         Index = index,
                                         CuePoints = item.CuePoints
                                     }).Where(t => t.CuePoints.Contains(cuePoint)).First();
                if (!_dgvTracks.Rows[track.Index].Selected) //not yet selected?
                {
                    //select now
                    _dgvTracks.Rows[track.Index].Selected = true;
                    _dgvTracks.FirstDisplayedScrollingRowIndex = track.Index;
                    _dgvTracks.Refresh();
                }


                //select the cuepoint in the details view
                foreach (DataGridViewRow item in _dgvCuePoints.Rows)
                {
                    var data = item.Cells[1].Value;
                    var reference = cuePoint.Shortcut;
                    if (data.Equals(reference))
                    {
                        if (!item.Selected) //not yet selected?
                        {
                            //select now
                            item.Selected = true;
                            _dgvCuePoints.FirstDisplayedScrollingRowIndex = item.Index;
                            _dgvCuePoints.Refresh();

                            break; //the forech loop as we now have our row
                        }
                    }
                }
            }

        }

        /// <summary>
        /// Handles the SelectionChanged event of the _dgvTracks control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void _dgvTracks_SelectionChanged(object sender, EventArgs e)
        {
            //put the cues of the selected track into the details view
            //get the selected track
            var selectedRows = _dgvTracks.SelectedRows;
            if (selectedRows.Count > 0) //any selected?
            {
                var selectedRow = selectedRows[0];
                var index = selectedRow.Index;

                var cuePoints = Compilation.Tracks[index].CuePoints;

                _dgvCuePoints.DataSource = cuePoints.Select(cue =>
                                new
                                {
                                    Description = cue.Description,
                                    Shortcut = cue.Shortcut
                                }).ToList(); //usage of toList is necessary for databinding with a datagridview
            }


        }

        private void _dgvCuePoints_SelectionChanged(object sender, EventArgs e)
        {
            CuePoint cuePoint = GetSelectedCuePoint();
            OnCuePointSelected(cuePoint);
        }

        /// <summary>
        /// Gets the currently selected cue point.
        /// </summary>
        private CuePoint GetSelectedCuePoint()
        {
            //get the selected track
            var selectedRows = _dgvTracks.SelectedRows;
            if (selectedRows.Count > 0) //any selected?
            {
                var selectedRow = selectedRows[0];
                var index = selectedRow.Index;

                var cuePoints = Compilation.Tracks[index].CuePoints;

                //get the selected cue point
                var selectedCuePointRows = _dgvCuePoints.SelectedRows;
                if (selectedCuePointRows.Count > 0) //any selected?
                {
                    var selectedCuePointRow = selectedCuePointRows[0];
                    var cuePointindex = selectedCuePointRow.Index;

                    return Compilation.Tracks[index].CuePoints[cuePointindex];


                }
            }
            return null; //in case this failed to find a selected cuepoint
        }

        /// <summary>
        /// Occurs when [cue point selected].
        /// </summary>
        public event EventHandler<CuePointEventArgs> CuePointSelected;

        /// <summary>
        /// Occurs when [cue point playing requested].
        /// </summary>
        public event EventHandler<CuePointEventArgs> CuePointPlayingRequested;

        /// <summary>
        /// Called when [cue point selected].
        /// </summary>
        /// <param name="cuePoint">The cue point.</param>
        private void OnCuePointSelected(CuePoint cuePoint)
        {
            if (CuePointSelected != null) //anyone listening?
            {
                CuePointEventArgs args = new CuePointEventArgs();
                args.CuePoint = cuePoint;
                CuePointSelected(this, args);
            }
        }

        private void OnCuePlayingRequested(CuePoint cuePoint)
        {
            if (CuePointPlayingRequested != null) //anyone listening?
            {
                CuePointEventArgs args = new CuePointEventArgs();
                args.CuePoint = cuePoint;
                CuePointPlayingRequested(this, args);
            }
        }

        private void _dgvCuePoints_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //simply use the selected cue point for the play request.
            CuePoint cuePoint = GetSelectedCuePoint();
            OnCuePlayingRequested(cuePoint);
        }
    }
}
