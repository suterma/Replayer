﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Xml.Serialization;
using System.IO;
using System.Threading;
using RePlayer.Core.Input;
using RePlayer.Core.Media;
using RePlayer.Core.Data;
using RePlayer.Face.WinForms.Helpers;
using Microsoft.SqlServer.MessageBox;
using RePlayer.Core;
using RePlayer.Compilation.Html;
using RePlayer.Face.WinForms.Component;
using RePlayer.Core.Player;
using RePlayer.Core.Annotation.v03;


namespace AdoniaReplayerProto
{
    /// <summary>
    /// A replayer for rehearsal Compilations.
    /// </summary>
    public partial class RePlayerApplicationForm : Form
    {     
        /// <summary>
        /// Initializes a new instance of the <see cref="RePlayerApplicationForm"/> class.
        /// </summary>
        public RePlayerApplicationForm()
        {
            InitializeComponent();

            //register player in the model
            Model.Instance.Player = this._windowsMediaRePlayer;

            //install keyboard hook
            this.KeyPress += (sender, e) =>
            {
                Model.Instance.KeyboardInputHandler.HandleKeyPress(new SimpleKeyPressEventArgs 
                { 
                    Handled = e.Handled ,
                    KeyChar = e.KeyChar
                });
                e.Handled = true; //do not allow handling elsewhere
            };
            this.KeyDown += (sender, e) =>
            {
                if (e.Alt)                //is modified?
                {
                    return;//do not handle here, let pass further
                }

                Model.Instance.KeyboardInputHandler.HandleKeyDown(new SimpleKeyEventArgs            {                Handled = e.Handled            });
                e.Handled = true; //do not allow handling elsewhere
               
            };
            this.KeyUp += (sender, e) =>
            {
                if (e.Alt)                //is modified?
                {
                    return;//do not handle here, let pass further
                }
                Model.Instance.KeyboardInputHandler.HandleKeyUp(new SimpleKeyEventArgs { Handled = e.Handled });
                e.Handled = true; //do not allow handling elsewhere
               
            };
            this.KeyPreview = true; //handle on form level first before any control

            Model.Instance.KeyboardInputHandler.KeySequenceChanged += (sender, e) => this.labelKeySequence.Text = e.Sequence; //used just for GUI updates

            //Handle cue points of the view
            compilationView.CuePointSelected += new EventHandler<CuePointEventArgs>(CompilationView_CuePointSelected);
            compilationView.CuePointPlayingRequested += new EventHandler<CuePointEventArgs>(CompilationView_CuePointPlayingRequested);

            Model.Instance.PropertyChanged += new PropertyChangedEventHandler(Model_PropertyChanged);

            ExhibitCompilation(); //exhibits the currently loaded compilation (in case one got already loaded automatically by the model)
        }

        /// <summary>
        /// Handles the PropertyChanged event of the Model control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.PropertyChangedEventArgs"/> instance containing the event data.</param>
        void Model_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Compilation")
            {
                if (Model.Instance.Compilation != null) //new compilation is valid?
                {
                    //register to file missing event, to handle user file searches also for this new compilation
                    Model.Instance.Compilation.FileMissing += Compilation_FileMissing;

                    ExhibitCompilation();
                }                
            }
            else if (e.PropertyName.Equals("SelectedCue"))
            {
                this.compilationView.SelectCuePoint(Model.Instance.SelectedCue);
            }
        }

        /// <summary>
        /// Loads the Compilation at the specified url, with some GUI beauty
        /// </summary>
        /// <param name="url">The URL.</param>
        private void LoadCompilation(string url)
        {
            this._toolStripProgressBar1.Style = ProgressBarStyle.Marquee;
            this._lblLoadedCompilationName.Text = @"Loading...";
            this.Enabled = false;
            _compilationLoaderBackgroundWorker.RunWorkerAsync(url);
        }

        /// <summary>
        /// Exhibits the compilation.
        /// </summary>
        private void ExhibitCompilation()
        {
            if (Model.Instance.Compilation != null) //there is any Compilation loaded?
            {
           compilationView.Compilation = Model.Instance.Compilation;
                _lblLoadedCompilationName.Text = Model.Instance.Compilation.Url.Jolted(40);

            }
        }

        /// <summary>
        /// Handles the CuePointPlayingRequested event of the CompilationView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RePlayer.Core.Compilation.CuePointEventArgs"/> instance containing the event data.</param>
        void CompilationView_CuePointPlayingRequested(object sender, CuePointEventArgs e)
        {
             Model.Instance.Player.State = Handling.State.Playing; //start to play, as requested
        }

        /// <summary>
        /// Handles the CuePointSelected event of the CompilationView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RePlayer.Core.Compilation.CuePointEventArgs"/> instance containing the event data.</param>
        void CompilationView_CuePointSelected(object sender, CuePointEventArgs e)
        {            
            Model.Instance.SelectedCue = e.CuePoint;//go to that cuepoint         
        }

        /// <summary>
        /// Handles the FileMissing event of the Compilation.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="args">The <see cref="Replayer.Core.Data.EventArgs&lt;System.String&gt;"/> instance containing the event data.</param>
        void Compilation_FileMissing(object sender, EventArgs<string> args)
        {
            string userPath = RequestMediapathFromUser(args.Data);
            args.Data = userPath; //return back the selected path
        }


        /// <summary>
        /// Requests the mediapath from user.
        /// </summary>
        /// <param name="info">The info.</param>
        /// <returns></returns>
        private string RequestMediapathFromUser(String info)
        {
            DialogResult result;

            //request path from user
            MessageBox.Show("Media file not found. Please browse for: " + info, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //browse for media
            //openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Title = "Browse for: " + info;
            openFileDialog1.InitialDirectory = ".";
            openFileDialog1.Filter = "Media files (*.mp3)|*.mp3";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            openFileDialog1.Multiselect = false;
            result = openFileDialog1.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                return openFileDialog1.FileName;
            }
            else
            {
                return String.Empty;
            }
        }

        /// <summary>
        /// Handles the Click event of the openToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = ".";
            openFileDialog1.Filter = "Compilation files (*.xml, *.zip)|*.xml;*.zip";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            openFileDialog1.Multiselect = false;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                LoadCompilation(openFileDialog1.FileName);
            }
        }

        /// <summary>
        /// Handles the Click event of the saveToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Model.Instance.Compilation.Store();
            }
            catch (ArgumentException) //if the file path is invalid
            {
                //try to save as...
                saveAsToolStripMenuItem_Click(sender, e);
            }

        }

        /// <summary>
        /// Handles the Click event of the newToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //let the user select the media files first:
            DialogResult result;

            //browse for media
            //openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Title = "Browse for the media files you like to use in the Compilation: ";
            openFileDialog1.InitialDirectory = ".";
            openFileDialog1.Filter = "Media files (*.mp3;*.wav)|*.mp3;*.wav";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            openFileDialog1.Multiselect = true;
            result = openFileDialog1.ShowDialog();
            if (result != System.Windows.Forms.DialogResult.OK) //not ok?
            {
                return; //exit here
            }

            //now create a new Compilation
            ICompilation created = new XmlCompilation();
            created.MediaPath = Path.GetDirectoryName(openFileDialog1.FileName); //use the directory of the selected file as media directory
            created.Url = String.Empty;
            created.Title = "New Compilation";
            int trackIndex = 1; //an index to the cuepoints in the track annotation, to create some initial shortcut
            foreach (var item in openFileDialog1.FileNames)
            {
                TrackAnnotation annotation = new TrackAnnotation();
                CuePoint intro = new CuePoint();
                intro.Description = "Intro";
                intro.Shortcut = (10 * trackIndex++).ToString();
                intro.Time = 0;
                annotation.CuePoints.Add(intro);
                TrackInfo trackInfo = new TrackInfo();
                trackInfo.Artist = "Unknown";
                trackInfo.Album = "Unkown";
                trackInfo.LocalPath = item;
                trackInfo.Measure = 0;
                trackInfo.Name = Path.GetFileNameWithoutExtension(item);
                annotation.TrackInfo = trackInfo;

                created.Tracks.Add(annotation);
            }

            //use the new Compilation as the current Compilation
            Model.Instance.Compilation = created;
        }

        /// <summary>
        /// Handles the Click event of the contentsToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void contentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("iexplore.exe", "replayer.codeministry.ch");
        }

        /// <summary>
        /// Handles the Click event of the aboutToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (AboutBox aboutBox = new AboutBox())
            {
                aboutBox.ShowDialog();
            }

        }

        /// <summary>
        /// Handles the Click event of the saveAsToolStripMenuItem control.
        /// </summary>
        /// <remarks>Saving is possible to all formats that can also get opened
        /// back.</remarks>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Displays a SaveFileDialog so the user can save the compilaton
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "XML compilation|*.xml|ZIP compilation|*.zip";
            saveFileDialog1.Title = "Save a compilation to a new location";
            saveFileDialog1.ShowDialog();

            // If the file name is not an empty string open it for saving.
            if (saveFileDialog1.FileName != "")
            {
                // Saves the compilation in the appropriate format based upon the
                // File type selected in the dialog box.
                // NOTE that the FilterIndex property is one-based.
                // Based on the type do a conversion
                switch (saveFileDialog1.FilterIndex)
                {
                    case 1: //XML
                        {
                            if (!(Model.Instance.Compilation is XmlCompilation)) //conversion needed?
                            {
                                Model.Instance.Compilation = CompilationFactory.Convert<XmlCompilation>(Model.Instance.Compilation);
                            }

                        }
                        break;
                    case 2: //ZIP
                        {
                            if (!(Model.Instance.Compilation is ZipCompilation)) //conversion needed?
                            {
                                Model.Instance.Compilation = CompilationFactory.Convert<ZipCompilation>(Model.Instance.Compilation);
                            }

                        }
                        break;

                }
                Model.Instance.Compilation.Store(saveFileDialog1.FileName); //save the eventually converted session to the specified filename now

                //update label
                _lblLoadedCompilationName.Text = Model.Instance.Compilation.Url.Jolted(40);
            }
        }

        /// <summary>
        /// Handles the Click event of the editToolStripMenuItem1 control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void editToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            ///TODO create a custom property grid editor that allows editing the whole
            ///Compilation object at runtime

            new CompilationEditor(Model.Instance.Compilation).ShowDialog();
        }

        /// <summary>
        /// Handles the Click event of the exportToolStripMenuItem control.
        /// </summary>
        /// <remarks>Exportin is possible for all formats that
        /// could not get opened back.</remarks>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void exportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Displays a SaveFileDialog so the user can export the compilaton
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "List Webpage compilation|*.html|Menu Webpage compilation|*.html";
            saveFileDialog1.Title = "Export a compilation";
            saveFileDialog1.ShowDialog();

            // If the file name is not an empty string open it for saving.
            if (saveFileDialog1.FileName != "")
            {
                // Saves the compilation in the appropriate format based upon the
                // File type selected in the dialog box.
                // NOTE that the FilterIndex property is one-based.
                // Based on the type do a conversion
                switch (saveFileDialog1.FilterIndex)
                {
                    case 1: //List Webpage compilation
                        {
                            if (!(Model.Instance.Compilation is HtmlCompilation)) //conversion needed?
                            {
                                CompilationFactory.Convert<HtmlCompilation>(Model.Instance.Compilation).Store(saveFileDialog1.FileName);
                            }

                        }
                        break;
                    case 2: //Menu Webpage compilation
                        {
                            if (!(Model.Instance.Compilation is TiddlyWikiCompilation)) //conversion needed?
                            {
                                CompilationFactory.Convert<TiddlyWikiCompilation>(Model.Instance.Compilation).Store(saveFileDialog1.FileName);
                            }

                        }
                        break;
                }
            }
        }

        /// <summary>
        /// Handles the DoWork event of the _compilationLoaderBackgroundWorker control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.DoWorkEventArgs"/> instance containing the event data.</param>
        private void _compilationLoaderBackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                e.Result = CompilationFactory.Retrieve(e.Argument as string);
            }
            catch (Exception ex)
            {
                ExceptionMessageBox box = new ExceptionMessageBox(ex);
                box.Show(null);
            }
        }

        /// <summary>
        /// Handles the ProgressChanged event of the _compilationLoaderBackgroundWorker control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.ProgressChangedEventArgs"/> instance containing the event data.</param>
        private void _compilationLoaderBackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {

        }

        /// <summary>
        /// Handles the RunWorkerCompleted event of the _compilationLoaderBackgroundWorker control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.RunWorkerCompletedEventArgs"/> instance containing the event data.</param>
        private void _compilationLoaderBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            Model.Instance.Compilation = e.Result as ICompilation;//assign the loaded compilation now on this thread
            this.Enabled = true;
            this._toolStripProgressBar1.Style = ProgressBarStyle.Blocks;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
