﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RePlayer.Face.WinForms.Helpers
{
    /// <summary>
    /// Extensions for use within this assembly
    /// </summary>
    internal static class Extensions
    {
        /// <summary>
        /// Jolts a string to the specified lenght, using some of the first and the last part.
        /// </summary>
        /// <param name="joltedLength">The length.</param>
        /// <returns></returns>
        internal static string Jolted(this string full, int joltedLength)
        {
            // return full.Length > joltedLength ? full.Substring(full.Length - joltedLength) : full;
            return full.Length > joltedLength ? full.Substring(0, 3) + "..." + full.Substring(full.Length - (joltedLength - 6)) : full;
        }


    }
}
