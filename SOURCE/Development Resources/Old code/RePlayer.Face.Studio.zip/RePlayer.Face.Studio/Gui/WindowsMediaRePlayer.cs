﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using RePlayer.Core.Media;
using RePlayer.Core;
using RePlayer.Core.Player;
using RePlayer.Core.Player;

namespace RePlayer.Face.WinForms.Gui
{
    /// <summary>
    /// A Windows Media Player instance which is 
    /// usable as media player within the 
    /// RePlayer application
    /// </summary>
    public partial class WindowsMediaRePlayer : UserControl, IPlayer
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WindowsMediaRePlayer"/> class.
        /// </summary>
        public WindowsMediaRePlayer()
        {
            InitializeComponent();

            //do not autoplay
            axWindowsMediaPlayer.settings.autoStart = false;
        } 


        /// <summary>
        /// Gets or sets the position within the currently loaded media track.
        /// </summary>
        /// <value>The position.</value>
        public TimeSpan Position
        {
            get
            {
                return new TimeSpan((long)(axWindowsMediaPlayer.Ctlcontrols.currentPosition * 10000000)); //convert from ticks to seconds
            }
            set
            {
                //skip to position
                axWindowsMediaPlayer.Ctlcontrols.pause();
                axWindowsMediaPlayer.Ctlcontrols.currentPosition = value.TotalSeconds;

                //continue at new place if required.
                if (this.State.Equals(Handling.State.Playing))
                {
                    axWindowsMediaPlayer.Ctlcontrols.play();
                }
                OnPropertyChanged(this, "Position");
            }
        }

        /// <summary>
        /// Occurs when a property has changed it's value.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Seeks forward within the currently loaded media track.
        /// </summary>
        /// <param name="interval">The interval.</param>
        public void SeekForward(double interval)
        {
            this.Position = this.Position.Add(new TimeSpan((long)(interval * 10000000)));
        }

        /// <summary>
        /// Seeks backward within the currently loaded media track.
        /// </summary>
        /// <param name="interval">The interval.</param>
           public void SeekBackward(double interval)
        {
            this.Position = this.Position.Subtract(new TimeSpan((long)(interval * 10000000)));
        }

        ///// <summary>
        ///// Stops this instance.
        ///// </summary>
        //internal void Stop()
        //{
        //    this.State = Core.State.Paused;
        //    this.Position = _position; //return back to the position the playing originally started from
        //}

           /// <summary>
           /// Backing field.
           /// </summary>
           private Handling.State _state;

           /// <summary>
           /// Gets or sets the state.
           /// </summary>
           /// <value>The state.</value>
           public Handling.State State
        {
            get
            {
                return _state;
            }
            set
            {
                if (_state == value) //no change?
                    return;

                _state = value; //remember value

                //apply state to wrapped player
                switch (value)
                {
                    case Handling.State.Playing:
                        axWindowsMediaPlayer.Ctlcontrols.play();
                        break;
                    case Handling.State.Paused:
                        axWindowsMediaPlayer.Ctlcontrols.pause();
                        break;
                    default:
                        break;
                }
                OnPropertyChanged(this, "State");
            }
        }

        /// <summary>
        /// Toggles the play/pause state.
        /// </summary>
        public void TogglePlayPause()
        {
            switch (State)
            {
                case Handling.State.Playing:
                    State = Handling.State.Paused;
                    break;
                case Handling.State.Paused:
                    State = Handling.State.Playing;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Gets or sets the URL, which represents the current media to use.
        /// </summary>
        /// <value>The URL.</value>
        public string Url
        {
            get
            {
                return axWindowsMediaPlayer.URL;
            }
            set
            {
                if (!axWindowsMediaPlayer.URL.Equals(value))//value really changed?
                {
                    axWindowsMediaPlayer.URL = value; //set new value, causing the meadia to get loaded
                    OnPropertyChanged(this, "Url");
                }
            }
        }

        /// <summary>
        /// Gets or sets the volume. The value is expected to be in the range
        /// of 0 to 100.
        /// </summary>
        /// <value>The volume.</value>
        public double Volume
        {
            get
            {
                return axWindowsMediaPlayer.settings.volume;
            }
            set
            {
                double volume = value;
                volume = Math.Max(volume, 0);
                volume = Math.Min(volume, 100);
                axWindowsMediaPlayer.settings.volume = (int)value;
                OnPropertyChanged(this, "Volume");
            }
        }

        /// <summary>
        /// Called when [property changed].
        /// </summary>
        /// <remarks>
        /// OnPropertyChanged will raise the PropertyChanged event passing the
        /// source property that is being updated. 
        /// </remarks>
        /// <param name="sender">The sender.</param>
        /// <param name="propertyName">Name of the property.</param>
        private void OnPropertyChanged(object sender, string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                PropertyChanged(sender, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
