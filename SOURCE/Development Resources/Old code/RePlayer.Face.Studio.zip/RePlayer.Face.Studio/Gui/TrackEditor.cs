﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RePlayer.Face.WinForms.Gui
{
    public partial class TrackEditor : UserControl
    {
        public TrackEditor()
        {
            InitializeComponent();
        }
    }
}
