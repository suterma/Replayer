﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Replayer.Core.Media;
using Replayer.Core;
using Replayer.Core.Player;

namespace RePlayer.Face.WinForms.Gui
{
    /// <summary>
    /// A Windows Media Player instance which is controlled by the 
    /// Replayer model player state.
    /// </summary>
    public partial class ControlledWindowsMediaPlayer : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ControlledWindowsMediaPlayer"/> class.
        /// </summary>
        public ControlledWindowsMediaPlayer()
        {
            InitializeComponent();

            //do not autoplay
            axWindowsMediaPlayer1.settings.autoStart = false;

             //register to the action information of the media player model
            Model.Instance.PlayerState.PropertyChanged += new PropertyChangedEventHandler(PlayerState_PropertyChanged);
        
            //set initial values  
                ApplyPlayerStateUrl();          
                ApplyPlayerStateState();          
                ApplyPlayerStatePosition();          
                ApplyPlayerStateVolume();   
        }

        /// <summary>
        /// Handles the PropertyChanged event of the PlayerState control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.PropertyChangedEventArgs"/> instance containing the event data.</param>
        void PlayerState_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName.Equals("Url")) //url changed?
            {
                ApplyPlayerStateUrl();
            }
            else if (e.PropertyName.Equals("State")) //player state changed?
            {
                ApplyPlayerStateState();
            }
            else if (e.PropertyName.Equals("Position")) //position changed
            {
                ApplyPlayerStatePosition();
            }
            else if (e.PropertyName.Equals("Volume")) //volume changed?
            {
                ApplyPlayerStateVolume();
            }
        }

        /// <summary>
        /// Applies the player state volume.
        /// </summary>
        private void ApplyPlayerStateVolume()
        {
            axWindowsMediaPlayer1.settings.volume = (int)Model.Instance.PlayerState.Volume;
        }

        /// <summary>
        /// Applies the player state position.
        /// </summary>
        private void ApplyPlayerStatePosition()
        {
            //skip to position
            axWindowsMediaPlayer1.Ctlcontrols.pause();
            axWindowsMediaPlayer1.Ctlcontrols.currentPosition = Model.Instance.PlayerState.Position.TotalSeconds;

            //continue at new place if required.
            if (Model.Instance.PlayerState.State == Handling.State.Playing)
            {
                axWindowsMediaPlayer1.Ctlcontrols.play();
            }
        }

        /// <summary>
        /// Applies the state of the player state.
        /// </summary>
        private void ApplyPlayerStateState()
        {
            //apply state to wrapped player
            switch (Model.Instance.PlayerState.State)
            {
                case Handling.State.Playing:
                    axWindowsMediaPlayer1.Ctlcontrols.play();
                    break;
                case Handling.State.Paused:
                    axWindowsMediaPlayer1.Ctlcontrols.pause();
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Applies the player state URL.
        /// </summary>
        private void ApplyPlayerStateUrl()
        {
            if (!axWindowsMediaPlayer1.URL.Equals(Model.Instance.PlayerState.Url))//value really changed?
            {
                axWindowsMediaPlayer1.URL = Model.Instance.PlayerState.Url; //set new value, causing the meadia to get loaded
            }
        }
    }
}
